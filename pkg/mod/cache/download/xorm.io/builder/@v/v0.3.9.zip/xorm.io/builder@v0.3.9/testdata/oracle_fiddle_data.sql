create table table1 (
  id number(9) not null primary key,
  a  varchar2(40),
  b  varchar2(40),
  c  varchar2(40)
);

create table table2 (
  id     number(9) not null primary key,
  ref_id number(9),
  d      varchar2(40)
);

INSERT INTO table1 (id, a, b, c)
VALUES (0, '0', '0', '0');
INSERT INTO table1 (id, a, b, c)
VALUES (1, '1', '1', '1');
INSERT INTO table1 (id, a, b, c)
VALUES (2, '2', '2', '2');
INSERT INTO table1 (id, a, b, c)
VALUES (3, '3', '3', '3');
INSERT INTO table1 (id, a, b, c)
VALUES (4, '4', '4', '4');
INSERT INTO table1 (id, a, b, c)
VALUES (5, '5', '5', '5');
INSERT INTO table1 (id, a, b, c)
VALUES (6, '6', '6', '6');
INSERT INTO table1 (id, a, b, c)
VALUES (7, '7', '7', '7');
INSERT INTO table1 (id, a, b, c)
VALUES (8, '8', '8', '8');
INSERT INTO table1 (id, a, b, c)
VALUES (9, '9', '9', '9');
INSERT INTO table1 (id, a, b, c)
VALUES (10, '10', '10', '10');
INSERT INTO table1 (id, a, b, c)
VALUES (11, '11', '11', '11');
INSERT INTO table1 (id, a, b, c)
VALUES (12, '12', '12', '12');
INSERT INTO table1 (id, a, b, c)
VALUES (13, '13', '13', '13');
INSERT INTO table1 (id, a, b, c)
VALUES (14, '14', '14', '14');
INSERT INTO table1 (id, a, b, c)
VALUES (15, '15', '15', '15');
INSERT INTO table1 (id, a, b, c)
VALUES (16, '16', '16', '16');
INSERT INTO table1 (id, a, b, c)
VALUES (17, '17', '17', '17');
INSERT INTO table1 (id, a, b, c)
VALUES (18, '18', '18', '18');
INSERT INTO table1 (id, a, b, c)
VALUES (19, '19', '19', '19');
INSERT INTO table1 (id, a, b, c)
VALUES (20, '20', '20', '20');
INSERT INTO table1 (id, a, b, c)
VALUES (21, '21', '21', '21');
INSERT INTO table1 (id, a, b, c)
VALUES (22, '22', '22', '22');
INSERT INTO table1 (id, a, b, c)
VALUES (23, '23', '23', '23');
INSERT INTO table1 (id, a, b, c)
VALUES (24, '24', '24', '24');
INSERT INTO table1 (id, a, b, c)
VALUES (25, '25', '25', '25');
INSERT INTO table1 (id, a, b, c)
VALUES (26, '26', '26', '26');
INSERT INTO table1 (id, a, b, c)
VALUES (27, '27', '27', '27');
INSERT INTO table1 (id, a, b, c)
VALUES (28, '28', '28', '28');
INSERT INTO table1 (id, a, b, c)
VALUES (29, '29', '29', '29');
INSERT INTO table1 (id, a, b, c)
VALUES (30, '30', '30', '30');
INSERT INTO table1 (id, a, b, c)
VALUES (31, '31', '31', '31');
INSERT INTO table1 (id, a, b, c)
VALUES (32, '32', '32', '32');
INSERT INTO table1 (id, a, b, c)
VALUES (33, '33', '33', '33');
INSERT INTO table1 (id, a, b, c)
VALUES (34, '34', '34', '34');
INSERT INTO table1 (id, a, b, c)
VALUES (35, '35', '35', '35');
INSERT INTO table1 (id, a, b, c)
VALUES (36, '36', '36', '36');
INSERT INTO table1 (id, a, b, c)
VALUES (37, '37', '37', '37');
INSERT INTO table1 (id, a, b, c)
VALUES (38, '38', '38', '38');
INSERT INTO table1 (id, a, b, c)
VALUES (39, '39', '39', '39');
INSERT INTO table1 (id, a, b, c)
VALUES (40, '40', '40', '40');
INSERT INTO table1 (id, a, b, c)
VALUES (41, '41', '41', '41');
INSERT INTO table1 (id, a, b, c)
VALUES (42, '42', '42', '42');
INSERT INTO table1 (id, a, b, c)
VALUES (43, '43', '43', '43');
INSERT INTO table1 (id, a, b, c)
VALUES (44, '44', '44', '44');
INSERT INTO table1 (id, a, b, c)
VALUES (45, '45', '45', '45');
INSERT INTO table1 (id, a, b, c)
VALUES (46, '46', '46', '46');
INSERT INTO table1 (id, a, b, c)
VALUES (47, '47', '47', '47');
INSERT INTO table1 (id, a, b, c)
VALUES (48, '48', '48', '48');
INSERT INTO table1 (id, a, b, c)
VALUES (49, '49', '49', '49');

INSERT INTO table2 (id, ref_id, d)
VALUES (0, '0', '0');
INSERT INTO table2 (id, ref_id, d)
VALUES (1, '1', '1');
INSERT INTO table2 (id, ref_id, d)
VALUES (2, '2', '2');
INSERT INTO table2 (id, ref_id, d)
VALUES (3, '3', '3');
INSERT INTO table2 (id, ref_id, d)
VALUES (4, '4', '4');
INSERT INTO table2 (id, ref_id, d)
VALUES (5, '5', '5');
INSERT INTO table2 (id, ref_id, d)
VALUES (6, '6', '6');
INSERT INTO table2 (id, ref_id, d)
VALUES (7, '7', '7');
INSERT INTO table2 (id, ref_id, d)
VALUES (8, '8', '8');
INSERT INTO table2 (id, ref_id, d)
VALUES (9, '9', '9');
INSERT INTO table2 (id, ref_id, d)
VALUES (10, '10', '10');
INSERT INTO table2 (id, ref_id, d)
VALUES (11, '11', '11');
INSERT INTO table2 (id, ref_id, d)
VALUES (12, '12', '12');
INSERT INTO table2 (id, ref_id, d)
VALUES (13, '13', '13');
INSERT INTO table2 (id, ref_id, d)
VALUES (14, '14', '14');
INSERT INTO table2 (id, ref_id, d)
VALUES (15, '15', '15');
INSERT INTO table2 (id, ref_id, d)
VALUES (16, '16', '16');
INSERT INTO table2 (id, ref_id, d)
VALUES (17, '17', '17');
INSERT INTO table2 (id, ref_id, d)
VALUES (18, '18', '18');
INSERT INTO table2 (id, ref_id, d)
VALUES (19, '19', '19');
INSERT INTO table2 (id, ref_id, d)
VALUES (20, '20', '20');
INSERT INTO table2 (id, ref_id, d)
VALUES (21, '21', '21');
INSERT INTO table2 (id, ref_id, d)
VALUES (22, '22', '22');
INSERT INTO table2 (id, ref_id, d)
VALUES (23, '23', '23');
INSERT INTO table2 (id, ref_id, d)
VALUES (24, '24', '24');
INSERT INTO table2 (id, ref_id, d)
VALUES (25, '25', '25');
INSERT INTO table2 (id, ref_id, d)
VALUES (26, '26', '26');
INSERT INTO table2 (id, ref_id, d)
VALUES (27, '27', '27');
INSERT INTO table2 (id, ref_id, d)
VALUES (28, '28', '28');
INSERT INTO table2 (id, ref_id, d)
VALUES (29, '29', '29');
INSERT INTO table2 (id, ref_id, d)
VALUES (30, '30', '30');
INSERT INTO table2 (id, ref_id, d)
VALUES (31, '31', '31');
INSERT INTO table2 (id, ref_id, d)
VALUES (32, '32', '32');
INSERT INTO table2 (id, ref_id, d)
VALUES (33, '33', '33');
INSERT INTO table2 (id, ref_id, d)
VALUES (34, '34', '34');
INSERT INTO table2 (id, ref_id, d)
VALUES (35, '35', '35');
INSERT INTO table2 (id, ref_id, d)
VALUES (36, '36', '36');
INSERT INTO table2 (id, ref_id, d)
VALUES (37, '37', '37');
INSERT INTO table2 (id, ref_id, d)
VALUES (38, '38', '38');
INSERT INTO table2 (id, ref_id, d)
VALUES (39, '39', '39');
INSERT INTO table2 (id, ref_id, d)
VALUES (40, '40', '40');
INSERT INTO table2 (id, ref_id, d)
VALUES (41, '41', '41');
INSERT INTO table2 (id, ref_id, d)
VALUES (42, '42', '42');
INSERT INTO table2 (id, ref_id, d)
VALUES (43, '43', '43');
INSERT INTO table2 (id, ref_id, d)
VALUES (44, '44', '44');
INSERT INTO table2 (id, ref_id, d)
VALUES (45, '45', '45');
INSERT INTO table2 (id, ref_id, d)
VALUES (46, '46', '46');
INSERT INTO table2 (id, ref_id, d)
VALUES (47, '47', '47');
INSERT INTO table2 (id, ref_id, d)
VALUES (48, '48', '48');
INSERT INTO table2 (id, ref_id, d)
VALUES (49, '49', '49');